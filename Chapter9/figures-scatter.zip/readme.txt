This zip has the plots for chapter 9 and 2 animations.
The figure_CB3D.gif animation has a title which is just a little bit
outside the frame of the gif, I haven't been able to fix this.
It says: "The paths of 4 planets and the sun in 3D for 3.0 years"

Dani van Enk, 11823526